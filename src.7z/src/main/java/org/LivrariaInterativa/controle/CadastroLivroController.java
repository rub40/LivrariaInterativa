package org.LivrariaInterativa.controle;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.TypedQuery;

import org.LivrariaInterativa.modelo.Sessao;
import org.LivrariaInterativa.repositorio.SessaoRepositorio;
import org.springframework.stereotype.Controller;

@Controller
public class CadastroLivroController {

	private EntityManager manager;
	private List<Sessao> listaSessao;
	
	public CadastroLivroController() {
		super();
		BuscarSessoes();
	}

	private void BuscarSessoes() {
		SessaoRepositorio rep = new SessaoRepositorio();
		listaSessao = rep.getSessoes();
	}
}
