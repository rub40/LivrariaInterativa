package org.LivrariaInterativa.controle;


import org.LivrariaInterativa.modelo.Carrinho;
import org.LivrariaInterativa.repositorio.LivroRepositorio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.context.WebApplicationContext;

@Controller
@Scope(value=WebApplicationContext.SCOPE_REQUEST)
public class CarrinhoController {
	private LivroRepositorio repositorio;
	private Carrinho carrinho;

	@Autowired
	public CarrinhoController(LivroRepositorio repositorio, Carrinho carrinho) {
		this.repositorio = repositorio;
		this.carrinho = carrinho;
	}
	
	@RequestMapping("listarLivrosCliente")
	public String getProdutosLoja(Model model) {
		model.addAttribute("produtos", repositorio.Listar());
		
		return "listarLivrosCliente";
	}
	
	@RequestMapping("listarLivrosCarrinho")
	public String getProdutosCarrinho(Model model) {
		model.addAttribute("carrinho", carrinho.getProdutos());
		
		return "carrinho";
	}
	
	@RequestMapping("adicionarLivroCarrinho")
	public String adicionarProduto(int id) {
		if(repositorio.verificaEstoque(id))
			carrinho.Adicionar(repositorio.busca(id));
		
		return "redirect:listarLivrosCarrinho";
	}
	
	@RequestMapping("removerLivroCarrinho")
	public String removerProduto(int id) {
		carrinho.RemoverProduto(id);
		
		return "redirect:listarLivrosCarrinho";
	}
}
