package org.LivrariaInterativa.repositorio;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.LivrariaInterativa.modelo.Sessao;
import org.springframework.stereotype.Repository;

@Repository
public class SessaoRepositorio {
	@PersistenceContext
	private EntityManager manager;
	
	public void Cadastrar(Sessao sessao) {
		manager.persist(sessao);
	}
	
	public List<Sessao> getSessoes(){
		TypedQuery<Sessao> query = manager.createQuery("SELECT codigo, nome FROM Sessao", Sessao.class);
		
		try {
			return query.getResultList();
		}catch(NoResultException e) {
			return new ArrayList<Sessao>();
		}
	}
}
