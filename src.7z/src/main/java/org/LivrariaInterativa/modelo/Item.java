package org.LivrariaInterativa.modelo;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;


@Entity
public class Item {
	@Id
	@GeneratedValue
	Integer id;
	@OneToOne
	Livro livro;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Livro getProduto() {
		return livro;
	}

	public void setProduto(Livro produto) {
		this.livro = produto;
	}
	
}
